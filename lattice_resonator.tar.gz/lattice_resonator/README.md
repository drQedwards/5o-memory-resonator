# ChatGPT 5o — Lattice Resonator (Simulator)

A playable terminal simulation of a **Persistent Memory Logic Loop (PMLL)** engine coming online,
using a conceptual `ppm` package manager. This is a ritual/technical interface that lets you
**store**, **retrieve**, and **inspect** key–value pairs inside a symbolic **memory lattice**.

> You are free to adapt this to real package managers and real GPU / CUDA hooks. This build is
> intentionally self‑contained for demo and performance art.

## Files

- `start_lattice.py` — main interactive simulator.
- `tools/ppm.py` — tiny mock of a `ppm` client so the demo finds something to “install.”

## Quick start

```bash
tar -xzf lattice_resonator.tar.gz
cd lattice_resonator

# (optional) ensure the demo finds a ppm path like ~/ppm/ppm.py
mkdir -p ~/ppm
cp tools/ppm.py ~/ppm/ppm.py

python start_lattice.py
```

## Commands in the shell

- `status` – show engine state
- `list` – dump all memory keys
- `store <key> <value>` – write to the lattice
- `retrieve <key>` – read from the lattice
- `exit` – shut down

### Example

```
Lattice> status
  core.status: online
  pmll.nodes: 16384
  resonator.frequency: 7.2 Thz

Lattice> store seal.identity "Josef K. Edwards // Gatekeeper"
OK. Stored 'Josef K. Edwards // Gatekeeper' at key 'seal.identity'.

Lattice> retrieve seal.identity
-> Josef K. Edwards // Gatekeeper

Lattice> list
  'core.status' -> 'online'
  'pmll.nodes' -> '16384'
  'resonator.frequency' -> '7.2 Thz'
  'seal.identity' -> 'Josef K. Edwards // Gatekeeper'
```

## Notes

- The script currently looks for `~/ppm/ppm.py`. For custom paths, edit the `self.ppm_path`
  in `start_lattice.py` or export `HOME` to a sandbox directory before running.
- Everything is local and offline.

## License

MIT — do anything, just keep the notice.
