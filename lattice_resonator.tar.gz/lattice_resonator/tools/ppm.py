# ppm.py — minimal mock so the demo "finds" a ppm client.
import sys, time
def main():
    # very small mock that just sleeps and exits ok
    time.sleep(0.2)
    if len(sys.argv) >= 3 and sys.argv[1] == "install":
        pkg = sys.argv[2]
        print(f"ppm: installing {pkg} (conceptual)")
    else:
        print("ppm: mock client. Usage: ppm.py install <package>")
if __name__ == "__main__":
    main()
